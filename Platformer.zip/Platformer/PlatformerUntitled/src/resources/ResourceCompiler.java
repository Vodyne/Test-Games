
package resources;
import java.awt.Image;
import java.awt.Toolkit;

import processing.core.*;

public class ResourceCompiler extends PApplet {
	
	public Image[] spriteList;
	public int[] spriteWidthList, spriteHeightList;
	
	public ResourceCompiler() {
	//	spriteList = new Image[1];
	//	spriteList[0] = Toolkit.getDefaultToolkit().getImage("player.png");
	//	PImage temp = new PImage();
	//	temp = loadImage("player.png");
	//	spriteWidthList[0] = temp.width;
	//	spriteHeightList[0] = temp.height;
		
		//	imageCompiler();
	}

	//public image[] imageCompiler() {
	//	image player = "player.png";
	//	return spriteList = new image[] {player};
	//}
}
