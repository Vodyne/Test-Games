package main;

import java.awt.geom.Ellipse2D;
import java.awt.geom.Rectangle2D;
import java.awt.Shape;
//import java.awt.geom.RectangularShape;
//import java.awt.Rectangle;

public class Platform2 extends Game2 {
	//  boolean touchPlatformLeft, touchPlatformRight, touchPlatformBottom, touchPlatformTop;
	float x, y, width, height;
	float xPan, yPan;
	float z;	//parallax functionality should not be applied to objects with hitboxes, set z = 0. this is because this game code does not alter the positions of objects, only their drawn positions. this works for zoom and pan but not when pans between two objects are different such as is this case. in order to get this functionality, the actual coordinate system must be changed too... or at least... an equivalent to hitbox coords must be created like x&yPan were for x&y for drawing
	int index;
	int[] color;

	
	public Platform2(float x, float y, float width, float height, int i, int[] color, float z) {
		this.x = x;
		this.y = y;
		this.width = width;
		this.height = height;
		index = i;
		
		xPan = x;
		yPan = y;
		
		this.z = z;
		
		if (color != null)
			this.color = color;
	}
	public Rectangle2D createRectangle2D() {
		return new Rectangle2D.Float(x, y, width, height);
	}
	public Rectangle2D createRectangle2DToDraw() {
		return new Rectangle2D.Float(xPan, yPan, width, height);
	}
//	public Rectangle2D createRectangle2DFromCentre() {
//		return new Rectangle2D.Float(xPlatform-xPlatformSideLength/2, yPlatform-yPlatformSideLength/2, xPlatformSideLength, yPlatformSideLength);
//	}
	public void updateFromRect(Rectangle2D r) {
		x = (float)r.getX();
		y = (float)r.getY();
		width = (float)r.getWidth();
		height = (float)r.getHeight();
	}
	public boolean withinHitboxRect(Rectangle2D entity) {
		return createRectangle2D().intersects(entity);
	}
	public boolean withinHitboxRectDrawn(Rectangle2D entity) {
		return createRectangle2DToDraw().intersects(entity);
	}
	public boolean withinHitboxCoords(float x, float y, float width, float height) {
		return createRectangle2D().intersects(x, y, width, height);
	}
	public float[] getCentre() {
		return new float[] {x+width/2, y+height/2};
	}
	/*
	public void updateRect() {
		r.setRect(xPlatform, yPlatform, xPlatformSideLength, yPlatformSideLength);
	}
	*/



	
	
	
	
	//dont think i need these unless i make the vars private... why would i want to? maybe so i can call a var then edit it within a method without it actually affecting var unless i have a setVar() method. why not then just assign var value to a temp var?
	public float getX() {
		return x;
	}
	public float getY() {
		return y;
	}
	public float getWidth() {
		return width;
	}
	public float getHeight() {
		return height;
	}
	public int getIndex() {
		return index;
	}
	public int[] getColor() {
		return color;
	}
	public float getXPan() {
		return xPan;
	}
	public float getYPan() {
		return yPan;
	}
	public float getZ() {
		return z;
	}

	
	
	public void setX(float input) {
		x = input;
	}
	public void setY(float input) {
		y = input;
	}
	public void setWidth(float input) {
		width = input;
	}
	public void setHeight(float input) {
		height = input;
	}
	public void setIndex(int input) {
		index = input;
	}
	public void setColor(int[] input) {
		color = input;
	}
	public void setXPan(float input) {
		xPan = input;
	}
	public void setYPan(float input) {
		yPan = input;
	}
	public void resetXYPan() {
		xPan = x;
		yPan = y;
	}
	public void setZ(float input) {
		z = input;
	}
	public void setXandXPan(float input) {
		x = input;
		xPan = input;
	}
	public void setYandYPan(float input) {
		y = input;
		yPan = input;
	}
	public void setXY(float[] input) {
		x = input[0];
		y = input[1];
	}
	public void setXYZ(float[] input) {
		x = input[0];
		y = input[1];
		z = input[2];
	}
	public void updateFromCoords(float x, float y, float width, float height) {
		this.x = x;
		this.y = y;
		this.width = width;
		this.height = height;
	}
	
	
	
	
	public void addToX(float input) {
		x += input;
	}
	public void addToY(float input) {
		y += input;
	}
	public void addToWidth(float input) {
		width += input;
	}
	public void addToHeight(float input) {
		height += input;
	}
	public void addToIndex(int input) {
		index += input;
	}
	public void addToColor(int[] input) {	//make sure color and input are same length! (or at least color <= input)
		for (int i = 0; i < color.length; i++)
			color[i] += input[i];
	}
	public void addToXPan(float input) {
		xPan += input;
	}
	public void addToYPan(float input) {
		yPan += input;
	}
	public void addToZ(float input) {
		z += input;
	}
	public void addToXandXPan(float input) {
		x += input;
		xPan += input;
	}
	public void addToYandYPan(float input) {
		y += input;
		yPan += input;
	}
	public void addToXY(float[] input) {
		x += input[0];
		y += input[1];
	}
	public void addToXYZ(float[] input) {
		x += input[0];
		y += input[1];
		z += input[2];
	}
	
}

