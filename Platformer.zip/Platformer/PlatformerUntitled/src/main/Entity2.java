package main;

import java.awt.geom.Rectangle2D;
import processing.core.PImage;
import java.awt.geom.Ellipse2D;

public class Entity2 extends Game2 {

	float[] xKin;
	float[] yKin;
	float xPan, yPan;
	float z;
	float width, height;
	float[] movementSpeed;
	float[] centre;
	int[] color;
	int index;
	
	PImage sprite;
	
	public Entity2(float[] xKin, float[] yKin, float width, float height, float xSpeed, float ySpeed, int[] color, float z, PImage sprite) {
		this.xKin = xKin;
		this.yKin = yKin;
		this.width = width;
		this.height = height;
		movementSpeed = new float[] {xSpeed, ySpeed};
		
		xPan = xKin[0];
		yPan = yKin[0];
		
		this.z = z;
		
		if (color != null)
			this.color = color;
		
		if (sprite != null) {
			this.sprite = sprite;
			this.sprite.width = Math.round(width);		//this is better
			this.sprite.height = Math.round(height);
		}
	}

	public Rectangle2D createRectangle2D() {	
		return new Rectangle2D.Float(xKin[0], yKin[0], width, height);
	}
	public Rectangle2D createRectangle2DToDraw() {	
		return new Rectangle2D.Float(xPan, yPan, width, height);
	}
	public boolean withinHitboxRect(Rectangle2D entity) {
		return createRectangle2D().intersects(entity);
	}
	public boolean withinHitboxRectDrawn(Rectangle2D entity) {
		return createRectangle2DToDraw().intersects(entity);
	}
	public boolean withinHitboxCoords(float x, float y, float width, float height) {
		return createRectangle2D().intersects(x, y, width, height);
	}
	public float[] getCentre() {	//updates centre as well, if you dont need update, get rid of "centre =" and declaration in class
		return centre = new float[] {xKin[0]+width/2, yKin[0]+height/2};
	}
	/*
	public Rectangle2D createRectangle2DFromCentre() {	
		return new Rectangle2D.Float(xPlayer[0]+xPlayerSideLength, yPlayer[0]+yPlayerSideLength, xPlayerSideLength, yPlayerSideLength);
	}
	
	public Ellipse2D createCircle(float[] centre, float radius) {	
		float x = centre[0] - radius;
		float y = centre[1] - radius;
		float diameter = radius*2;
		return new Ellipse2D.Float(x,y,diameter,diameter);
	}
	
	public boolean inPlayerRange(Rectangle2D entity) {
		return createCircle(new float[] {xPlayer[0]+xPlayerSideLength/2, yPlayer[0]+yPlayerSideLength/2}, 400).intersects(entity);
	}
	*/
	
	
	
	//for hitbox checking
	public boolean leftOf(Platform2 p) {
		return (xKin[0]+width <= p.getCentre()[0]);		//the equals will favor left
	}
	public boolean rightOf(Platform2 p) {
		return (xKin[0] > p.getCentre()[0]);
	}
	public boolean aboveOf(Platform2 p) {
		return (yKin[0] >= p.getCentre()[1]);			//the equals will favor above
	}
	public boolean belowOf(Platform2 p) {
		return (yKin[0]+height < p.getCentre()[1]);
	}
	
	
	
	public float getXPos() {
		return xKin[0];
	}
	public float getXVel() {
		return xKin[1];
	}
	public float getXAcc() {
		return xKin[2];
	}
	public float getYPos() {
		return yKin[0];
	}
	public float getYVel() {
		return yKin[1];
	}
	public float getYAcc() {
		return yKin[2];
	}
	public float[] getX() {
		return xKin;
	}
	public float[] getY() {
		return yKin;
	}
	public float getWidth() {
		return width;
	}
	public float getHeight() {
		return height;
	}
	public int getIndex() {
		return index;
	}
	public int[] getColor() {
		return color;
	}
	public float getXPan() {
		return xPan;
	}
	public float getYPan() {
		return yPan;
	}
	public float getZ() {
		return z;
	}
	public float[] getMovementSpeed() {
		return movementSpeed;
	}
	
	
	
	public void setXPos(float input) {
		xKin[0] = input;
	}
	public void setXVel(float input) {
		xKin[1] = input;
	}
	public void setXAcc(float input) {
		xKin[2] = input;
	}
	public void setYPos(float input) {
		yKin[0] = input;
	}
	public void setYVel(float input) {
		yKin[1] = input;
	}
	public void setYAcc(float input) {
		yKin[2] = input;
	}
	public void setXPosYPos(float[] input) {
		xKin[0] = input[0];
		yKin[0] = input[1];
	}
	public void setXVelYVel(float[] input) {
		xKin[1] = input[0];
		yKin[1] = input[1];
	}
	public void setXAccYAcc(float[] input) {
		xKin[2] = input[0];
		yKin[2] = input[1];
	}
	public void setX(float[] input) {
		xKin = input;
	}
	public void setY(float[] input) {
		yKin = input;
	}
	public void setWidth(float input) {
		width = input;
	}
	public void setHeight(float input) {
		height = input;
	}
	public void setIndex(int input) {
		index = input;
	}
	public void setColor(int[] input) {
		color = input;
	}
	public void setXPan(float input) {
		xPan = input;
	}
	public void setYPan(float input) {
		yPan = input;
	}
	public void resetXYPan() {
		xPan = xKin[0];
		yPan = yKin[0];
	}
	public void setZ(float input) {
		z = input;
	}
	public void setXPosYPosZ(float[] input) {
		xKin[0] = input[0];
		yKin[0] = input[1];
		z = input[2];
	}
	public void setXPosandXPan(float input) {
		xKin[0] = input;
		xPan = input;
	}
	public void setYPosandYPan(float input) {
		yKin[0] = input;
		yPan = input;
	}
	public void setXY(float[][] input) {
		xKin = input[0];
		yKin = input[1];
	}
	public void setXYZ(float[][] input) {	//z will pull the first value of the last array
		xKin = input[0];
		yKin = input[1];
		z = input[2][0];
	}
	public void updateFromCoords(float x, float y, float width, float height) {
		xKin[0] = x;
		yKin[0] = y;
		this.width = width;
		this.height = height;
	}
	
	
	
	public void addToXPos(float input) {
		xKin[0] += input;
	}
	public void addToXVel(float input) {
		xKin[1] += input;
	}
	public void addToXAcc(float input) {
		xKin[2] += input;
	}
	public void addToYPos(float input) {
		yKin[0] += input;
	}
	public void addToYVel(float input) {
		yKin[1] += input;
	}
	public void addToYAcc(float input) {
		yKin[2] += input;
	}
	public void addToX(float[] input) {	//input must be at least as long as xKin[3]
		for (int i = 0; i < xKin.length; i++)
			xKin[i] += input[i];
	}
	public void addToY(float[] input) { //input must be at least as long as yKin[3]
		for (int i = 0; i < yKin.length; i++)
			yKin[i] += input[i];
	}
	public void addToWidth(float input) {
		width += input;
	}
	public void addToHeight(float input) {
		height += input;
	}
	public void addToIndex(int input) {
		index += input;
	}
	public void addToColor(int[] input) {	//make sure color and input are same length! (or at least color <= input)
		for (int i = 0; i < color.length; i++)
			color[i] += input[i];
	}
	public void addToXPan(float input) {
		xPan += input;
	}
	public void addToYPan(float input) {
		yPan += input;
	}
	public void addToZ(float input) {
		z += input;
	}
	public void addToXPosandXPan(float input) {
		xKin[0] += input;
		xPan += input;
	}
	public void addToYPosandYPan(float input) {
		yKin[0] += input;
		yPan += input;
	}
	public void addToXY(float[][] input) {
		for (int i = 0; i < xKin.length; i++)
			xKin[i] += input[0][i];
		for (int i = 0; i < yKin.length; i++)
			yKin[i] += input[1][i];
	}
	public void addToXYZ(float[][] input) {
		for (int i = 0; i < xKin.length; i++)
			xKin[i] += input[0][i];
		for (int i = 0; i < yKin.length; i++)
			yKin[i] += input[1][i];
		z += input[2][0]; //z will pull the first value of the last array
	}
	
}
