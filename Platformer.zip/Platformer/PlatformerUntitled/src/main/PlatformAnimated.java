package main;

import java.awt.geom.Rectangle2D;

public class PlatformAnimated extends Platform2 {
	
	
	boolean animateFrameState;
	int animateSpeed;
	
	public PlatformAnimated(float x, float y, float width, float height, int i, int[] color, float z, boolean animateFrameState, int animateSpeed) {
		super(x, y, width, height, i, color, z);
		this.animateFrameState = animateFrameState;
		this.animateSpeed = animateSpeed;
	}
	
	
	
	
	
	
	public boolean getAnimateFrameState() {
		return animateFrameState;
	}
	public int getAnimateSpeed() {
		return animateSpeed;
	}
	public void setAnimateFrameState(boolean input) {
		animateFrameState = input;
	}
	public void setAnimateSpeed(int input) {
		animateSpeed = input;
	}
	public void flipAnimateFrameState() {
		animateFrameState ^= true;	// = !animateFrameState[i]
	}
	public void addToAnimateSpeed(float input) {
		animateSpeed += input;
	}
	
	public void animateRainbow() {
		animateRainbowRect(this.createRectangle2DToDraw(), color, animateSpeed, z);
	}
	
	public void animateRainbowRect(Rectangle2D r, int[] c, int v, float z) {
		colorMode(HSB, 360, 100, 100, 100);
		if (c[0] >= 360-v)	//animateRainbowInt(c[0], v);
			c[0] = 0;		//*
		c[0]+=v;			//*
		drawRect(r, c, z);
		colorMode(RGB, 255, 255, 255, 255);
	}
	
	
}
