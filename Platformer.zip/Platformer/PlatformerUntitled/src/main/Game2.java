package main;

import resources.*;



import processing.core.PApplet;
import processing.core.PGraphics;
import processing.core.PImage;
import processing.event.MouseEvent;

import java.awt.Toolkit;
//import processing.core.PImage;
import java.awt.geom.Rectangle2D;

public class Game2 extends PApplet {	//if you want vars between instances ex. score, run in here outside of setup()

//	ResourceCompiler resourceComp;
	
	
	//Game settings
	boolean mouseWheelZoomEnabled = true;
	
	float[] transformCentre = new float[] {width/2,height/2};
	float[] newCameraCentre = new float[] {width/2,height/2};
	float[] oldCameraCentre = new float[] {width/2,height/2};
	float[] originalCameraCentre = new float[] {width/2,height/2};
	boolean movingCamera = false;
	float[] cameraVelocity = new float[2];
	
	float prevZoomMultiplier = 1;
	float newZoomMultiplier = 1;
	float oldZoomMultiplier = 1;
	float originalZoomMultiplier = 1;		//def dont need all this, same probably true for the pan equivalents above ^^^^
	boolean zoomingCamera = false;
	float zoomRatioVelocity;
	
	//changing x and y player to static seems to allow the hitboxes in Platform22 class to finally register; very lagged though. perhaps player class using GLOBAL variables (not static?) might help

	static float gravity;
	static float[] xPlayer;  //float xPlayerPos, xPlayerVel, xPlayerAcc; 0,1,2
	static float[] yPlayer;  //float yPlayerPos, yPlayerVel, yPlayerAcc; 0,1,2
	//float[] playerTraits; //{xPlayerSideLength, yPlayerSideLength, xPlayerSpeed, jumpVelocity};
	static float xPlayerSideLength, yPlayerSideLength, xPlayerSpeed, jumpVelocity, speedConverted, terminalVelocity;	//not needed if you use playerTraits[]
	//	  float xPlatform2, yPlatform2, xPlatform2SideLength, yPlatform2SideLength;
	boolean leftPressed, rightPressed, upPressed, downPressed, enterPressed, jPressed, lPressed, iPressed, kPressed, escPressed, backslashPressed, equalsPressed, minusPressed;
	float zoomLevel, zoomMultiplier, zoomIncrement, maxZoom;
	float parallaxIncrement, maxParallaxSpeed;
	boolean touchPlatform2Left, touchPlatform2Right, touchPlatform2Top, touchPlatform2Bottom;
	boolean touchBoundLeft, touchBoundRight, touchBoundUp, touchBoundDown;//, killPlayer;

	int score = 0, highScore = 0, deathCount = 0;
	static int xGoal, yGoal, goalWidth, goalHeight;
	PlatformAnimated goal;
	public boolean goalAnimateFrameState;
	public int goalAnimationSpeed;

	int numPlatform2s = 4 + (int) (Math.random()*6);
	boolean[] touchAnyPlatform2Left = new boolean[numPlatform2s], touchAnyPlatform2Right = new boolean[numPlatform2s], touchAnyPlatform2Top = new boolean[numPlatform2s], touchAnyPlatform2Bottom = new boolean[numPlatform2s];
	int[] platformsColor;
	int j = numPlatform2s;
	int k = numPlatform2s;

	Platform2[] platforms;
	Entity2 player1;
	Entity2 camera1;
	
	Platform2 floor;
	Platform2 worldFrame;
	//Player p1 = new Player();
	
	Platform2 background;
	Platform2 clouds;
	
	
	boolean firstRun;
	boolean bindToPlayer;
	
	boolean updateDraw;
	int count;

	
	
	
	
	
	
	
	

	public static void main(String[] args) {
		PApplet.main("main.Game2");
	}

	public void settings() {
		//renderers, P2D, P3D, FX2D fast and native to apple but cant zoom, PDF, SVG
		
	//	size(1280, 720);
		//size(880, 620);
		
		//size(1920, 1080);	
		size(1536, 864, P2D);	//for default renderer, seems to be a large FPS cutoff at 1.4M pixels, so this is ~ max size. 60 fps is still plenty good but feels weird in the game. Works fine with P2D
		//fullScreen(P2D);
	}

	public void setup() { //runs once at beginning		//each time run is new instance of game
		
		noStroke();
		frameRate(90);
		
		surface.setResizable(true);		//why cant this go in settings()?
		
		//resourceComp = new ResourceCompiler();
		
		enterPressed = false;
		
		//set,reset zoom values
		zoomLevel = zoomIncrement = 10;	//	1/zoomIncrement, # of increments per 1; i.e. =20 1.05, 1.10, 1.15, etc		//faster zoom = lower zoomIncrement
		zoomMultiplier = 1;
		maxZoom = 10; //minZoom = 1/maxZoom
		
		parallaxIncrement = 10;
		maxParallaxSpeed = 10;

		//set world variables
		gravity = -0.2f;
		terminalVelocity = -15;	
		
		//set player variables
		xPlayerSideLength = 32;
		yPlayerSideLength = 32;
		xPlayerSpeed = 3;
		jumpVelocity = 10; //jumpVel must be < terminalVelocity to make sense, unless you hit it on the way up too?	

		//set platform variables
		numPlatform2s = 4 + (int) (Math.random()*6);		//4 = min, 6 = max - min
		touchAnyPlatform2Left = new boolean[numPlatform2s];
		touchAnyPlatform2Right = new boolean[numPlatform2s];
		touchAnyPlatform2Top = new boolean[numPlatform2s];
		touchAnyPlatform2Bottom = new boolean[numPlatform2s];		//cant string all in one bc it thinks they are the same but maybe compress somehow, or maybe string just doesnt work with more than two??
		j = numPlatform2s;
		k = numPlatform2s;		//seems to work as stringed j=k=num; but to be safe wont.  also refer here ^^^^
		//setup platforms - vars aren't used again
		player1 = new Entity2(new float[3], new float[3], xPlayerSideLength, yPlayerSideLength, xPlayerSpeed, jumpVelocity, null, 0, null);	//creation just for playerspeed use in platform withinDistrance, and playerwidth&height for tooClose()

		count = 0;
		
		platforms = new Platform2[numPlatform2s];
		platformsColor = new int[] {12, 232, 132, 255};	// not currently being used but would likely go here, then in platform creation just call variable name isntead of new int[]
		spawnPlatforms(platforms);
		
		
		//spawn player on top of platform[0]
		xPlayer = new float[] {(int) (platforms[0].getX()+(platforms[0].getWidth()-xPlayerSideLength)/2), 0, 0};
		yPlayer = new float[] {platforms[0].getY()+platforms[0].getHeight(), 0, gravity};
		player1 = new Entity2(xPlayer, yPlayer, xPlayerSideLength, yPlayerSideLength, xPlayerSpeed, jumpVelocity, new int[] {243, 23, 123, 255}, 0, loadImage("resources/player.png", "png"));	//new PImage(resourceComp.spriteList[0])		//image(new PImage(resourceComp.spriteList[0]), 0, 0)

		//camera
		camera1 = new Entity2(new float[] {0,0,0}, new float[] {0,0,0}, width, height, 3, 3, null, 0, null);		//should work enter null if no sprite
		originalCameraCentre = camera1.getCentre(); //why is this here? shouldn't oCamCentre always be width/2 height/2 ??
		bindToPlayer = true;
		
		//set goal variables
		xGoal = width/2;
		yGoal = height/2;
		goalWidth = 16;
		goalHeight = 16;
		goalAnimateFrameState = false;
		goalAnimationSpeed = 1;
		spawnGoal();
	
		//lava floor drawing
		floor = new Platform2(0, 0, width, 10, 0, new int[] {255,127,0,255}, 0);
		
		//worldFrame
		worldFrame = new Platform2(0, 0, width, height, 0, new int[] {0,0,70,155}, 0);
		
		
		//background & clouds test
		background = new Platform2(-width*5/2, -height*5/2, width*6, height*6, 0, new int[] {0,0,70,155}/*{27,155,155,255}*/, -50);	//x,y should = -width,-height - this.width,this.height / 2		//i.e. x,y = -3w, -3h - w,h /2 = -2w/2,-2h/2 =-w,-h
		clouds = new Platform2(0, 0, width, height, 0, new int[] {255,255,255,55}, 50);
		
		//w*k = w2 * Z2 / Z1
		//i.e.  background.width * k = clouds.width * zToZoomFactor(clouds.getZ()) / zToZoomFactor(background.getZ())
		
		
		firstRun = true;		//used to insure proper panTransformation on first draw after setup
		
		

	}
	
	public void draw() { //runs every frame
	//	background(0, 0, 45); //RGB
		loadOrder();
	}
	
	public void loadOrder() {	
		
		//player motion and conventional hitboxes (in this case platforms)
		xPlayerMotion();
		checkXHitboxes(platforms);
		yPlayerMotion();
		checkYHitboxes(platforms);
		setMasterHitbox();

		
		
		
		
		
		
		//goal "hitbox"
		checkGoalHitbox();
		
		//wall interior hitbox
		checkWallHitbox();	//was after pan and zoom, why? a reason?

		//camera before draw
		cameraMotion();

		//ifMovingCamera();
		ifZoomingCamera();
	//	panTransformWorldCamera3();	//...2 seems to be smoother, less method calls?
		
		//draw
		drawOrder();
		
		
		firstRun = false;	//used to insure proper panTransformation on first draw after setup
		
		
		
		
		if (enterPressed)
			setup();
		if (backslashPressed)
			resetCamera();
		if(jPressed || kPressed || lPressed || iPressed)	//ifMovingCamera() doesn't really work but i guess thats okay
			bindToPlayer = false;		//use for locking camera to player if you want to implement
	
	}
	/*
	public void worldGeneration() {
		Object[] world = new Object[] {background, worldFrame, platforms, player1, floor, goal, clouds};
		for (int i = 0; i < world.length; i++)
			drawRect(world[i]);
		
	}
	*/
	public void drawOrder() {
		background(0, 0, 45);
		drawRect				(background);
		//drawRect				(worldFrame);
		
		drawFrameExternal(worldFrame, new int[] {255,255,255,255}, 5);
		
		//paintDistance();
		drawPlatform2s			(platforms);
		drawEntity				(player1);
		drawRect				(floor);
		animateRainbowRect		(goal);
		drawRect				(clouds);
		drawScoreText();
//		drawDebugText();
	}

	
	
	
	public void xPlayerMotion() {	//no support for gravity i believe		
		player1.setXVel( (leftPressed == rightPressed) ? 0 : (leftPressed ? -1 : 1)*player1.getMovementSpeed()[0] );
		player1.addToXPosandXPan(player1.getXVel());
	}
	
	public void yPlayerMotion() {	//only unidirectional support for gravity i believe
		//Player y motion with key input 
		if (upPressed && (touchPlatform2Top || touchBoundDown))
			player1.addToYVel(player1.getMovementSpeed()[1]);
		//gravity
		if (/*!touchPlatform2Top &&*/ !touchBoundDown && player1.getYVel() >= terminalVelocity)	//had to get rid of this !touchPlatform2Top bc added bug when added if(enterPressed) to draw() that when stacking enter resets, touchingPlatform2Top = true permanently bc hitbox registers enough but transport player far enough away for it to register false; so quick fix just run gravity when on platform
			player1.addToYVel(player1.getYAcc());
		//else;
		player1.addToYPosandYPan(player1.getYVel());
	}
	
	public void checkXHitboxes(Platform2[] plats) {
		for (Platform2 p : plats)
			checkXHitbox(p);
	}
	public void checkYHitboxes(Platform2[] plats) {
		for (Platform2 p : plats)
			checkYHitbox(p);
	}
	public void checkXHitbox(Platform2 p) {			//dont base off of velocity but rather position relative to center of platform!
		int i = p.getIndex();
		if (player1.withinHitboxRect(p.createRectangle2D()))  { //left && right && upper bound && lower bound
			float entityWidth = player1.getWidth(), entityXVel = player1.getXVel(), entityCentreY = player1.getCentre()[0];
			float pX = p.getX(), pXPan = p.getXPan(), pWidth = p.getWidth(), pCentreX = p.getCentre()[0];
			if (entityXVel > 0 || (entityCentreY <= pCentreX)) {
				player1.setXPos(pX - entityWidth);
				player1.setXPan(pXPan - entityWidth);
				player1.setXVel(0);
				touchAnyPlatform2Left[i] = true;
				j = p.getIndex();
			}
			else if (entityXVel < 0 || (entityCentreY > pCentreX)) {
				player1.setXPos(pX + pWidth);
				player1.setXPan(pXPan + pWidth);
				player1.setXVel(0);
				touchAnyPlatform2Right[i] = true;
				j = p.getIndex();
			}
			/*
			else {
				if (player1.getCentre()[0] <= p.getCentre()[0]) { // = in >= favors left
					player1.setXPos(pX - entityWidth);
					player1.setXPan(pXPan - entityWidth);
				}
				else {
					player1.setXPos(pX + p.getWidth());
					player1.setXPan(pXPan + p.getWidth());
				}
			}
			*/
		}
		else
			touchAnyPlatform2Left[i] = touchAnyPlatform2Right[i] = false;
	}
	public void checkYHitbox(Platform2 p) {
		int i = p.getIndex();
		if (player1.withinHitboxRect(p.createRectangle2D()))  {
			float entityHeight = player1.getHeight(), entityYVel = player1.getYVel(), entityCentreY = player1.getCentre()[1];
			float pY = p.getY(), pYPan = p.getYPan(), pHeight = p.getHeight(), pCentreY = p.getCentre()[1];
			if (entityYVel > 0 || (entityCentreY < pCentreY)) {
				player1.setYPos(pY - entityHeight);
				player1.setYPan(pYPan - entityHeight);
				player1.setYVel(0);
				touchAnyPlatform2Bottom[i] = true;
				k = i;			
			}
			else if (entityYVel < 0 || (entityCentreY >= pCentreY)) {	
				player1.setYPos(pY + pHeight);
				player1.setYPan(pYPan + pHeight);
				player1.setYVel(0);
				touchAnyPlatform2Top[i] = true;
				k = i;
			} 
			/*
			else {
				if (player1.getCentre()[1] < p.getCentre()[1]) {
					player1.setYPos(pY - entityHeight);
					player1.setYPan(pYPan - entityHeight);
				}
				else { // = in >= favors up
					player1.setYPos(pY + p.getHeight());
					player1.setYPan(pYPan + p.getHeight());
				}
			}
			*/
		}
		else
			touchAnyPlatform2Top[i] = touchAnyPlatform2Bottom[i] = false;
	}
	
	public void setMasterHitbox() {	//change? --> OR gate for all i 0-n? instead of just at j,k?
		if (j < numPlatform2s) {
			touchPlatform2Left = touchAnyPlatform2Left[j];
			touchPlatform2Right = touchAnyPlatform2Right[j];
		}
		if (k < numPlatform2s) {
			touchPlatform2Top = touchAnyPlatform2Top[k];
			touchPlatform2Bottom = touchAnyPlatform2Bottom[k];
		}
	}

	public void checkWallHitbox() {		//interior hitbox(player, object)
		//x
		float entityXPos = player1.getXPos(), entityWidth = player1.getWidth();
		float edgeX = worldFrame.getX(), edgeXPan = worldFrame.getXPan(), edgeWidth = worldFrame.getWidth();
		if (entityXPos >= edgeX + edgeWidth - entityWidth)  { //right wall
			player1.setXPos(edgeX + edgeWidth - entityWidth);
			player1.setXPan(edgeXPan + edgeWidth - entityWidth);
			player1.setXVel(0);
			touchBoundRight = true;
		}
		else if (entityXPos <= edgeX)  { //left wall
			player1.setXPos(edgeX);
			player1.setXPan(edgeXPan);
			player1.setXVel(0);
			touchBoundLeft = true;
		}
		else
			touchBoundLeft = touchBoundRight = false;
		
		//y
		float entityYPos = player1.getYPos(), entityHeight = player1.getHeight();
		float edgeY = worldFrame.getY(), edgeYPan = worldFrame.getYPan(), edgeHeight = worldFrame.getHeight();
		if (entityYPos >= edgeY + edgeHeight - entityHeight)  { //up wall
			player1.setYPos(edgeY + edgeHeight - entityHeight);
			player1.setYPan(edgeYPan + edgeHeight - entityHeight);
			player1.setYVel(0);
			touchBoundUp = true;
		}
		else if (entityYPos <= edgeY)  {  //down wall
			player1.setYPos(edgeY);
			player1.setYPan(edgeYPan);
			player1.setYVel(0);
			touchBoundDown = true;
			
			killPlayer();
		}
		else
			touchBoundUp = touchBoundDown = false;
		}
	
	public void killPlayer() {
		deathCount++;
		resetScore();
		setup();
	}
	
	public void resetScore() {
		highScore = (score > highScore) ? score : highScore;
		score = 0;
	}
	
	public void cameraMotion() {
		float m = camera1.getMovementSpeed()[0]*zToZoomFactor(camera1.getZ());
		camera1.setXVel( (jPressed == lPressed) ? 0 : (jPressed ? -1 : 1)*m );
		camera1.addToXPos(camera1.getXVel());
		camera1.setYVel( (kPressed == iPressed) ? 0 : (kPressed ? -1 : 1)*m );
		camera1.addToYPos(camera1.getYVel());
	}
	
	public void panTransformWorldCamera3() {
		if (ifMovingCamera()) {
			//platforms
			for (Platform2 p : platforms) {
				panTransform(p);
			}
			//player
			panTransform(player1);
			//goal
			panTransform(goal);
			//floor
			panTransform(floor);
			//worldFrame
			panTransform(worldFrame);
			//background & clouds test
			panTransform(background);
			panTransform(clouds);
			
		}
	}

	public void panTransform(Platform2 p) {
		float l = zToZoomFactor(p.getZ());
		float m = (float)Math.pow(zoomMultiplier,-l);
		p.addToXPan(-cameraVelocity[0]*l*m);
		p.addToYPan(-cameraVelocity[1]*l*m);
	}
	public void panTransform(Entity2 e) {
		float l = zToZoomFactor(e.getZ());
		float m = (float)Math.pow(zoomMultiplier,-l);
		e.addToXPan(-cameraVelocity[0]*l*m);
		e.addToYPan(-cameraVelocity[1]*l*m);
	}
	
	public void panTransformReset() {		
		camera1.setXPosYPosZ(new float[] {0,0,0});	//interestingly, this isnt here, resetCamera() does not actually change the values of the cameraPos obviously, BUT yet this has no effect as visually it works perfectly
		//platforms
		for (Platform2 p : platforms) {
			p.resetXYPan();
		}
		//player
		player1.resetXYPan();
		//goal
		goal.resetXYPan();
		//floor
		floor.resetXYPan();
		//worldFrame
		worldFrame.resetXYPan();
		//background & clouds test
		background.resetXYPan();
		clouds.resetXYPan();
	}
	public void resetCamera() {
		backslashPressed = false;
		firstRun = true;
		bindToPlayer = true;
		//reset zoom values
		zoomLevel = 10;
		zoomMultiplier = 1;

		panTransformReset();
	}
	
	public boolean ifMovingCamera() { //must come after ifCameraMotion?
		//transformCentre = camera1.getCentre() of last frame
		
		cameraVelocity = (!firstRun) ? new float[] {camera1.getCentre()[0] - transformCentre[0], camera1.getCentre()[1] - transformCentre[1]} : new float[] {0,0};	//used to insure proper panTransformation on first draw after setup 		//this is because during the first run I was quite suspicious of the cameraVelocity value so I want to set it to zero for first run. ad lo and behold this fixed the bug where at startup camera was already panned, and also when you panned and setup() ran it would be panned opposite and you would have to run setup() again 
		if (camera1.getCentre()[0] == transformCentre[0] && camera1.getCentre()[1] == transformCentre[1]) {
			movingCamera = false;
			oldCameraCentre = camera1.getCentre();
		}
		else {
			movingCamera = true;
			newCameraCentre = camera1.getCentre();
		}
		transformCentre = camera1.getCentre();
		return movingCamera;
	}
	
	public boolean ifZoomingCamera() { //must come after ifCameraMotion?
		//transformCentre = camera1.getCentre() of last frame
		zoomRatioVelocity = zoomMultiplier - prevZoomMultiplier;
		if (zoomMultiplier == prevZoomMultiplier) {
			zoomingCamera = false;
			oldZoomMultiplier = zoomMultiplier;
		}
		else {
			zoomingCamera = true;
			newZoomMultiplier = zoomMultiplier;
		}
		prevZoomMultiplier = zoomMultiplier;
		return zoomingCamera;
	}
	/*
	public void drawRect(Object o) {
		if (o
		drawRect(o.cast(o.getType());
	}
	*/
	public void drawRect(Platform2 p) {
		drawRect(p.createRectangle2DToDraw(), p.getColor(), p.getZ());
	}
	public void drawRect(Entity2 e) {
		drawRect(e.createRectangle2DToDraw(), e.getColor(), e.getZ());
	}
	public void drawRect(Rectangle2D r, int[] c, float z) {
		if (camera1.getZ() >= z) {
			fill(c[0], c[1], c[2], c[3]);
			r = zoomTransform(r, z);
			rect((float)r.getX(), (float)r.getY(), (float)r.getWidth(), (float)r.getHeight());
		}
	}
	
	public void drawSprite(PImage sprite, Rectangle2D r, float z) {
		if (camera1.getZ() >= z) {
			sprite.resize((Math.round((float)r.getWidth()*zToZoomFactor(z-camera1.getZ()))), (Math.round((float)r.getHeight()*zToZoomFactor(z-camera1.getZ()))));		//sprite.width? or r.getWidth()
			image(sprite, (float)zoomTransform(r, z).getX(), (float)zoomTransform(r, z).getY());
		}
	}
	public void drawEntity(Entity2 p) {
		drawRect(p);
		//drawSprite(p.sprite, p.createRectangle2DToDraw(), p.getZ());
	}
	
	public Rectangle2D currentScreen() {
		return new Rectangle2D.Float(0, 0, width, height);	//to debug go (...+100,...+100,...-200,...-200) or multiples of it
	}
	public Rectangle2D currentScreen2() {
		float m = zToZoomFactor(camera1.getZ());
		float x = width/2*(1/m-1);
		float y = height/2*(1/m-1);
		return new Rectangle2D.Float(-x+100, -y+100, width/m-200, height/m-200);	//to debug go (...+100,...+100,...-200,...-200) or multiples of it
	}
	
	public void drawPlatform2s(Platform2[] plats) {
		for (Platform2 p : plats) {
			//		if (player1.inPlayerRange(p.createRectangle2D())) {
			if (zoomTransform(p.createRectangle2DToDraw(), p.getZ()).intersects(currentScreen())) {		//we need to use this on all drawn objects and entities not just platforms, use in draw world.
				drawRect(p);
				//this works but perhaps we want currentScreen() to already be converted,  cant figure out how to do it though
			}
		}
	}

	public void animateRainbowRect(PlatformAnimated pa) {
		animateRainbowRect(pa.createRectangle2DToDraw(), pa.getColor(), pa.getZ(), pa.getAnimateSpeed());
	}
	public void animateRainbowRect(Rectangle2D r, int[] c, float z, int v) {
		colorMode(HSB, 360, 100, 100, 100);
		if (c[0] >= 360-v)
			c[0] = 0;
		c[0]+=v;
		drawRect(r, c, z);
		colorMode(RGB, 255, 255, 255, 255);
	}
	
	public void spawnGoal() {
		for (Platform2 p : platforms)
			if (p.getY() < height-p.getHeight()-player1.getHeight()-goalHeight-20) {
				xGoal = (int) (p.getX()+(p.getWidth()-goalWidth)/2);
				yGoal = (int) ((p.getY() + p.getHeight()) + (player1.getHeight()-goalHeight)/2)+20;
			}
		goal = new PlatformAnimated(xGoal, yGoal, goalWidth, goalHeight, 0, new int[] {127, 180, 255, 255}, 0, goalAnimateFrameState, goalAnimationSpeed);
	}
	
	public void checkGoalHitbox() {
		if (goal.withinHitboxRect(player1.createRectangle2D())) {
			score++;
			setup();
		}
	}
	
	public int animateColorIntToFro(boolean animateFrameState, int color, int v) {	//	ex.	odrawGoal(new int[] {goalFillColor[0], goalFillColor[1], goalFillColor[2] = oanimateColorIntToFro(goalAnimateFrameState, goalFillColor[2], goalAnimationSpeed), goalFillColor[3]});
		if (color >= 255) {
			color = 255;
			animateFrameState = false;
		}
		else if (color <= 0) {
			color = 0;
			animateFrameState = true;
		}
		color += (animateFrameState) ? v : -v;	//if true, increasing; if false, decreasing
		return color;
	}
	public int animateColorIntToFro2(boolean animateFrameState, int color, int v) {	//	ex.	odrawGoal(new int[] {goalFillColor[0], goalFillColor[1], goalFillColor[2] = oanimateColorIntToFro(goalAnimateFrameState, goalFillColor[2], goalAnimationSpeed), goalFillColor[3]});
		color = (color >= 255) ? 255 : (color <= 0) ? 0 : color;
		animateFrameState = (color == 255) ? false : (color == 0) ? true : animateFrameState;
		color += (animateFrameState) ? v : -v;	//if true, increasing; if false, decreasing
		return color;
	}
	
	public void drawScoreText() {
		textSize(24);
		fill(124, 124, 246);
		text("Score: " + score, 32, 48);
		text("High Score: " + highScore, 32, 76);
		text("Deaths: " + deathCount, 32, 104);
		text("If impossible, press ENTER.", 32, 152);
	}
	public void drawDebugText() {
		speedConverted = (float) ((int) ((float) Math.sqrt(((float) Math.pow(player1.getXVel(), 2) + (float) Math.pow(player1.getYVel(), 2)))*10))/10;

		textSize(24);
		fill(124, 124, 246);
		text("Speed: "		+speedConverted+ " pixel per frame.", 	32, 48); 			// (string, x, y)

		text("Left: "		+touchPlatform2Left, 				32, 72+24+4);
		text("Right: "		+touchPlatform2Right, 				32, 72+48+8);
		text("Top: "		+touchPlatform2Top, 					32, 72+72+12);
		text("Bottom: "		+touchPlatform2Bottom, 				32, 72+96+16); 	//28

		text("LEFT: "		+leftPressed, 						32, 72+132+22);	//42
		text("RIGHT: "		+rightPressed, 						32, 72+156+26);
		text("UP: "			+upPressed, 						32, 72+180+32);
		text("DOWN: "		+downPressed, 						32, 72+204+38);

		text("Left Wall: "	+touchBoundLeft, 					32, 72+216+64);
		text("Right Wall: "	+touchBoundRight, 					32, 72+240+68);
		text("Top Wall: "	+touchBoundUp, 						32, 72+264+72);
		text("Bottom Wall: "+touchBoundDown, 					32, 72+288+76);

	//	text("xPlayer[0]: "						+player1.xKin[0],	32, 72+324+52);
	//	text("yPlayer[0]: "						+player1.yKin[0],	32, 72+348+56);

	//	text("framePosX: "						+worldFrame.getX(),	32, 72+324+52);
	//	text("framePanX: "						+worldFrame.getXPan(),	32, 72+348+56);

	//	text("bindToPlayer: "			+bindToPlayer,	32, 72+324+62);
		text("count: "			+count,	32, 72+324+62);
		
	//	text("mouseX: "		+mouseX,			32, 72+348+84);
	//	text("mouseY: "		+(height-mouseY),	32, 72+348+112);
//		text("zoomLevel: "	+zoomLevel,			32, 72+348+140);
//		text("zoomMultiplier: "	+zoomMultiplier,	32, 72+348+168);
		
		
		text("gc: "	+camera1.getCentre()[0]+","+camera1.getCentre()[1],		32, 72+348+84);
		text("oc: "	+oldCameraCentre[0]+","+oldCameraCentre[1],				32, 72+348+112);
		text("tc: "	+transformCentre[0]+","+transformCentre[1],	32, 72+348+140);
		text("nc: "	+newCameraCentre[0]+","+newCameraCentre[1],	32, 72+348+168);
	//	text("cs: "	+cameraVelocity[0]+","+cameraVelocity[1],	32, 72+348+196);
 
		
		text("zoomLevel: "	+zoomLevel,			32, 72+624+2);
		text("zoomMultiplier: "	+zoomMultiplier,	32, 72+648+6);
		text("zm: "	+zoomMultiplier, 		32, 72+648+34);
		text("ozm: "+oldZoomMultiplier,		32, 72+648+62);
		text("pzm: "+prevZoomMultiplier,	32, 72+648+90);
		text("nzm: "+newZoomMultiplier,		32, 72+648+118);
		text("zrv: "+zoomRatioVelocity,		32, 72+648+146);
		
		text("time: "+millis(),		32, 72+648+244);
		
		text("movingCamera: "	+movingCamera,	32, 72+348+224);						//	<------ this is helpful dont keep commented out forever
		text("zoomingCamera: "	+zoomingCamera,	32, 72+648+174);
//		text("nc: "	+newCameraCentre[0]+","+newCameraCentre[1],	32, 72+348+168);
//		text("cs: "	+cameraVelocity[0]+","+cameraVelocity[1],	32, 72+348+168);
		

		//text("hitbox2: "	+platforms[0].withinXHitbox2(), 	32, 72+312+258);
		//text("hitbox2: "	+platforms[0].withinYHitbox2(), 	32, 72+312+286);

	//	text("touchCords1: "	+ w1(), 32, 72+348+140);
	//	text("touchCords2: "	+ w2(), 32, 72+348+168);
		text("touchCords3: "	+ w3(), 32, 72+348+196);
		
		text("FPS: "	+(int)frameRate,	232, 72+0+0);
		text("size: "	+width*height,	432, 72+0+0);
		
		
		text("CamZ: "	+camera1.getZ(),	432, 272+0+0);
	}
	
	public void mouseWheelZoom(MouseEvent e) {
		zoomingCamera = (e.getCount()==0) ? false : true;
		zoomLevel -= e.getCount();
		if (zoomLevel < zoomIncrement && zoomLevel > -zoomIncrement-1)			
			zoomLevel = (e.getCount()<0) ? zoomIncrement : (e.getCount()>0) ? -zoomIncrement-1 : zoomLevel;
		zoomLevel = (zoomLevel > maxZoom*zoomIncrement) ? maxZoom*zoomIncrement : (zoomLevel < -maxZoom*zoomIncrement) ? -maxZoom*zoomIncrement : zoomLevel;
		zoomMultiplier = (zoomLevel > 0) ? zoomLevel/zoomIncrement : -zoomIncrement/zoomLevel;	//zoomLevel will never be 0 but if it was this will error bc else includes = 0
	}
	
	//add plus minus support via another method- actually do if to see if to use mouseevent or plusminus(in which case throw null mouseevent)
	
	public float zToZoomFactor(float z) {	//	100, 10
		return (z >= 0) ? z/parallaxIncrement+1 : 1/(1-z/parallaxIncrement);
	}
	
	public float zToParallaxSpeedFactor1(float z) {	//	100, 10
		float maxZ = maxParallaxSpeed*parallaxIncrement;
		z = (z > maxZ) ? maxZ : (z < -maxZ) ? -maxZ : z;
		z = (z >= 0) ? z/parallaxIncrement+1 : 1/(1-z/parallaxIncrement);
		return z;
	}
	
	public float zToParallaxSpeedFactorA(float z) {	//	100, 10
		z = (z > maxParallaxSpeed*parallaxIncrement) ? maxParallaxSpeed*parallaxIncrement : (z < -maxParallaxSpeed*parallaxIncrement) ? -maxParallaxSpeed*parallaxIncrement : z;
		return z = (z >= 0) ? z/parallaxIncrement+1 : 1/(1-z/parallaxIncrement);
	}
	
	public float zToParallaxSpeedFactor2(float zValue) {	//	100, 10
		float z = (float) zValue;
		float maxZ = maxParallaxSpeed*parallaxIncrement;
		z = (z > maxZ) ? maxZ : (z < -maxZ) ? -maxZ : z;
		float zdec = z/parallaxIncrement;
		z = (z >= 0) ? zdec+1 : 1/(1-zdec);
		return z;
	}


	
	public int w1() {
		int w = 0;
		for (Platform2 p : platforms)
			w += p.withinHitboxRect(player1.createRectangle2D()) ? 1: 0;
		return w;
	}
	
	public boolean w2() {
		boolean w = false;
		for (Platform2 p : platforms)
			w |= p.withinHitboxRect(player1.createRectangle2D());
		return w;
	}
	
	public String w3() {
		String s = "";
		for (Platform2 p : platforms)
			s += p.withinHitboxRect(player1.createRectangle2D()) ? p.getIndex(): "";
		return s;
	}
	


	public void keyPressed()  {  //will run if any key is pressed
		if (!leftPressed && (keyCode == LEFT/*37*/ || keyCode == 65/*a*/))
			leftPressed = true;
		if (!rightPressed && (keyCode == RIGHT/*39*/ || keyCode == 68/*d*/))
			rightPressed = true;
		if (!upPressed && (keyCode == UP/*38*/ || keyCode == 87/*w*/ || keyCode == 32/*spacebar*/))
			upPressed = true;
		if (!downPressed && (keyCode == DOWN/*40*/ || keyCode == 83/*s*/))
			downPressed = true;
		if (!enterPressed && keyCode == ENTER/*13*/) //dont think !enterPressed && is needed
			enterPressed = true;	//can put setup(); here for the reset function but i think its better outside
		if (!jPressed && keyCode == 74)
			jPressed = true;
		if (!lPressed && keyCode == 76)
			lPressed = true;
		if (!iPressed && keyCode == 73)
			iPressed = true;
		if (!kPressed && keyCode == 75)
			kPressed = true;
		if (!escPressed && keyCode == 27) {
			escPressed = true;
			key = 0;	//prevents processing from running exit() when esc is pressed
		}
		if (!backslashPressed && keyCode == 92) {
			backslashPressed = true;
			//resetCamera();
		}
		if (keyCode == 61) {
			equalsPressed = true;
			zoomToCameraZ(-1);
		}
		if (keyCode == 45) {
			minusPressed = true;
			zoomToCameraZ(1);
		}
	}

	public void keyReleased()  {  //will run if any key is released
		if (keyCode == LEFT/*37*/ || keyCode == 65/*a*/)
			leftPressed = false;
		if (keyCode == RIGHT/*39*/ || keyCode == 68/*d*/)
			rightPressed = false;
		if (keyCode == UP/*38*/ || keyCode == 87/*w*/ || keyCode == 32/*spacebar*/)
			upPressed = false;
		if (keyCode == DOWN/*40*/ || keyCode == 83/*s*/)
			downPressed = false;
		if (keyCode == ENTER/*13*/)
			enterPressed = false;
		if (keyCode == 74)
			jPressed = false;
		if (keyCode == 76)
			lPressed = false;
		if (keyCode == 73)
			iPressed = false;
		if (keyCode == 75)
			kPressed = false;
		if (keyCode == 27)
			escPressed = false;
		if (keyCode == 92)
			backslashPressed = false;
		if (keyCode == 61)
			equalsPressed = false;
		if (keyCode == 45)
			minusPressed = false;
	}

	public void mouseWheel(MouseEvent e) {
		if (mouseWheelZoomEnabled) {
			mouseWheelZoom(e);
			zoomToCameraZ(e.getCount());
		}
	}
	
	/*
	public void mousePressed() {
		line(mouseX, 10, mouseX, 90);
	}
	*/

	
	
	
	

	public void zoomToCameraZ1(MouseEvent e) { //4l, 2c, 4v		10
		float maxZ = maxParallaxSpeed*parallaxIncrement;
		float z = camera1.getZ();
		z += e.getCount();
		camera1.setZ((z>maxZ) ? maxZ : (z<-maxZ) ? -maxZ : z);
	}
	public void zoomToCameraZ(int i) { //4l, 2c, 4v		10
		float maxZ = maxParallaxSpeed*parallaxIncrement;
		float z = camera1.getZ();
		z += i;
		camera1.setZ((z>maxZ) ? maxZ : (z<-maxZ) ? -maxZ : z);
	}
	
	public void zoomToCameraZ2(MouseEvent e) { //5l, 2c, 4v		11
		float maxZ = maxParallaxSpeed*parallaxIncrement;
		float z = camera1.getZ();
		z += e.getCount();
		z = (z>maxZ) ? maxZ : (z<-maxZ) ? -maxZ : z;
		camera1.setZ(z);
	}
	
	public void zoomToCameraZ3(MouseEvent e) {	//4l, 3c, 4v	11
		float maxZ = maxParallaxSpeed*parallaxIncrement;
		camera1.addToZ(e.getCount());
		float z = camera1.getZ();
		camera1.setZ((z > maxZ) ? maxZ : (z < -maxZ) ? -maxZ : z);
	}
	
	public void zoomToCameraZ3C(MouseEvent e) { //2l, 5c, 8v	15
		camera1.addToZ(e.getCount());
		camera1.setZ((camera1.getZ() > maxParallaxSpeed*parallaxIncrement) ? maxParallaxSpeed*parallaxIncrement : (camera1.getZ() < -maxParallaxSpeed*parallaxIncrement) ? -maxParallaxSpeed*parallaxIncrement : camera1.getZ());
	}
	
	public Rectangle2D zoomTransform(Rectangle2D r, float z) {		//this is only drawn, real coordinate system is still original+panTransformWorld()
		float m = zToZoomFactor(z-camera1.getZ());
		float x = 				originalCameraCentre[0] + m*((float)r.getX()						-originalCameraCentre[0]-camera1.getXPos());
		float y = height-		originalCameraCentre[1] - m*((float)r.getY()+(float)r.getHeight()	-originalCameraCentre[1]-camera1.getYPos());
		return new Rectangle2D.Float(x, y, m*((float)r.getWidth()), m*((float)r.getHeight()));
	}
	
	public void drawFrameExternal(float x, float y, float width, float height, int[] c, float z, int lw) {
		drawRect( new Platform2(x-lw,		y-lw,		lw, 			height+lw*2, 	0, c, z) );
		drawRect( new Platform2(width, 		y-lw,		lw, 			height+lw*2, 	1, c, z) );
		drawRect( new Platform2(x-lw, 		y-lw, 		width+lw*2, 	lw,				2, c, z) );
		drawRect( new Platform2(x-lw, 		height, 	width+lw*2, 	lw,				3, c, z) );
	}
	public void drawFrameInternal(float x, float y, float width, float height, int[] c, float z, int lw) {
		drawRect( new Platform2(x,			y,				lw, 	height, 	0, c, z) );
		drawRect( new Platform2(x+width-lw, y,				lw, 	height, 	1, c, z) );
		drawRect( new Platform2(x, 			y, 				width, 	lw,			2, c, z) );
		drawRect( new Platform2(x, 			y+height-lw,	width, 	lw,			3, c, z) );
	}
	public void drawFrameExternal(Platform2 p, int[] c, int lw) {
		float x = p.getX(), y = p.getY(), z = p.getZ(), width = p.getWidth(), height = p.getHeight();
		drawRect( new Platform2(x-lw,		y-lw,		lw, 			height+lw*2, 	0, c, z) );
		drawRect( new Platform2(width, 		y-lw,		lw, 			height+lw*2, 	1, c, z) );
		drawRect( new Platform2(x-lw, 		y-lw, 		width+lw*2, 	lw,				2, c, z) );
		drawRect( new Platform2(x-lw, 		height, 	width+lw*2, 	lw,				3, c, z) );
	}
	public void drawFrameInternal(Platform2 p, int[] c, int lw) {
		float x = p.getX(), y = p.getY(), z = p.getZ(), width = p.getWidth(), height = p.getHeight();
		drawRect( new Platform2(x,				y,				lw, 	height, 	0, c, z) );
		drawRect( new Platform2(x+width-lw, 	y,				lw, 	height, 	1, c, z) );
		drawRect( new Platform2(x, 				y, 				width, 	lw,			2, c, z) );
		drawRect( new Platform2(x, 				y+height-lw, 	width, 	lw,			3, c, z) );
	}
	
	
	public void checkHitboxes(Platform2[] plats) {
		for (Platform2 p : plats) {
			checkXHitbox(p);
			checkYHitbox(p);
		}
	}
		
	/*
	public void setHitbox() {	//change? --> OR gate for all i 0-n? instead of just at j,k?
		String s = "";
		for (Platform2 p : platforms)
			s += p.withinHitboxRect(player1.createRectangle2D()) ? p.getIndex(): platforms.length;
		String[] w = s.split(""+platforms.length);
		
		if (w[0].length() > 0) {		//works but optional?

		int[] out = new int[w.length];
		for (int i = 0; i < w.length; i++) {
			out[i] = Integer.parseInt(w[i]);
		}
		
		for (int n : out) {
			checkHitbox(platforms[n]);
		}
		
		}
	}
*/
	public void paintDistance(/*Platform2 prev, Platform2 cur*/) {
		noFill();
		stroke(255);
		//show by xpan, calculate by x
		float jumpWidth = -2*player1.getMovementSpeed()[0]*player1.getMovementSpeed()[1]/gravity;
		float jumpHeight = player1.getMovementSpeed()[1]*player1.getMovementSpeed()[1]/(-2*gravity);
		float w = 3/2*player1.getMovementSpeed()[1]*player1.getMovementSpeed()[1];
		arc(w+player1.getXPan()+player1.getWidth(), height-player1.getYPan(), jumpWidth, jumpHeight, PI, TAU);
		arc(-w+player1.getXPan(), height-player1.getYPan(), jumpWidth, jumpHeight, PI, TAU);
		
		fill(255);
		float x = 0; //our first point will be at x=0
		float y = height;
		float h = 3/2*player1.getMovementSpeed()[1]*player1.getMovementSpeed()[1]+player1.getXPos();
		
		
		
		beginShape();
		while(y <= height) {
		  //compute a, add 0.01 so that denominator is never zero
		  float a = (height - mouseY) / (mouseX * mouseX + 0.01f);
		  //calculate y based on current x
		  y = a * (x - h) * (x - h) + mouseY;
		  //add vertex at x, y for our parabola
		  vertex(x, y);
		  //step x to draw point a little to the right  
		  x += 0.1;
		}
		endShape();
		
		noStroke();
	}
	
	public boolean withinDistance(Platform2 previous, Platform2 current) {
		float xL = current.getX();
		float xR = current.getX()+current.getWidth();
		float y = current.getY()+current.getHeight();
		
		float i = previous.getX();
		float j = previous.getY()+previous.getHeight();
		
		float vx = player1.getMovementSpeed()[0];
		float vy = player1.getMovementSpeed()[1];
		
		float t = -2*vy/gravity;
		float w = t*vx;
		float a = w*w/-4000;
		float k = vy*vy/(-2*gravity)+j;				//change playerPos to platform top corner
		float h = 3/2*vy*vy;
		float hR = h+i+previous.getWidth();			//change playerPos to platform top corner
		float hL = -h+i; 							//change playerPos to platform top corner
		
		
		float parabR = (xL-hR)*(xL-hR)-4*a*(y-k);
		float parabL = (xR-hL)*(xR-hL)-4*a*(y-k);
		Rectangle2D r = new Rectangle2D.Float(hL, j, hR-hL, k-j);	//bottom left, then top right
		
		return (parabR <= 0) || (parabL <= 0) || r.contains(xR, y+current.getHeight()) || r.contains(xL, y+current.getHeight());		//if >0, point outside; if ==0, point on; if <0, point inside
	}
	
	public boolean tooLow(Platform2 previous, Platform2 current) {
		float xL = current.getX();
		float xR = current.getX()+current.getWidth();
		float y = current.getY();
		
		float i = previous.getX();
		float j = previous.getY()+previous.getHeight();
		
		float vx = player1.getMovementSpeed()[0];
		float vy = player1.getMovementSpeed()[1];
		
		float t = -2*vy/gravity;
		float w = t*vx;
		float a = w*w/-4000;
		float k = vy*vy/(-2*gravity)+j+player1.getHeight();				//change playerPos to platform top corner
		float h = 3/2*vy*vy;
		float hR = h+i+previous.getWidth()-player1.getWidth();			//change playerPos to platform top corner
		float hL = -h+i+player1.getWidth(); 							//change playerPos to platform top corner
		
		
		float parabR = (xR-hR)*(xR-hR)-4*a*(y-k);
		float parabL = (xL-hL)*(xL-hL)-4*a*(y-k);
		
		return (parabR <= 0) && (parabL <= 0);		//if >0, point outside; if ==0, point on; if <0, point inside
	}
	
	public boolean tooClose(Platform2 previous, Platform2 current) {
		float x = previous.getX()-player1.getWidth();
		float y = previous.getY()-player1.getHeight();
		float w = previous.getWidth()+2*player1.getWidth();
		float h = previous.getHeight()+2*player1.getHeight();
		
		if(current.getIndex() == platforms.length-1) {
			y = previous.getY() - ( (player1.getHeight()-goalHeight)/2 +20 +goalHeight);
			h = h - player1.getHeight() + ( (player1.getHeight()-goalHeight)/2 +20 + goalHeight );
		}
		Rectangle2D newPrev = new Rectangle2D.Float(x, y, w, h);
		return current.withinHitboxRect(newPrev);
	}
	
	public boolean tooHigh(Platform2 p) {
		float j = p.getY()+p.getHeight();
		float vy = player1.getMovementSpeed()[1];
		float k = vy*vy/(-2*gravity)+j+player1.getHeight();
		return (k > height);
	}
	
	public void spawnPlatforms(Platform2[] platforms) {
		for (int i = 0; i < platforms.length; i++) {
			count++;
			spawnPlatform(i);
			if (i > 0) {
				//case 1, you could reverse order with case 1 and case two
				boolean withinDistance = false;
				for (int j = 0; j < i; j++) {
					withinDistance |= withinDistance(platforms[j], platforms[i]);
				}
				if (!withinDistance)
					i--;
				else {	//if passed case 1, run case 2
					boolean tooClose = false;
					for (int j = 0; j < i; j++) {
						tooClose |= tooClose(platforms[j], platforms[i]);
					}
					if (tooClose)
						i--;
					
					else {	//if pass case 2, run case 3
						boolean tooLow = false;
						for (int j = 0; j < i; j++) {
							tooLow |= tooLow(platforms[j], platforms[i]);
						}
						if (tooLow)
							i--;
						
						else {
							if (tooHigh(platforms[i]))
								i--;
						}
					}
				}
			}
		}
	}
	
	public void spawnPlatform(int i) {
		float heightPlatform2 = 20;
		float widthPlatform2 = (int) (Math.random()*100)+75;
	//	float xPlatform2 = (int) (Math.random()*(width-widthPlatform2));
		float xPlatform2 = (int) (Math.random()*(width-widthPlatform2-player1.getWidth()*2)+player1.getWidth());	//allows player to fit between wall and platform
		float yPlatform2 = (int) (Math.random()*(height-heightPlatform2));
		if (i==0)
			yPlatform2 = 0;	//make platform[0] start at bottom
		platforms[i] = new Platform2(xPlatform2, yPlatform2, widthPlatform2, heightPlatform2, i, new int[] {12, 36*i, 132, 255}, 0);
	}
	
	//to do
			//test different sizes of background and cloud
		//global variables for keypressed booleans
	//fix image quality falloff
	//i dont think its possible and if it is, it is likely very tedious/hard, but still need to consider hitting bottom of the worldFrame or another platform when making the parabola jump... when you hit the bottom, vy = 0 and the parabola has a new vertex...
	//potential to implement 2nd player with WASD or up/down/left/right (& remove spacebar jump)		//would also have to either not count player-player hitboxes, or implement collision feature		//would have to rewrite all methods involving player1 to take as input Entity[], run for each entity[] in each method... although platform distance will just be playerEntity[] and similar; and will possibly have to remove platform[0]'s specific spawning and spawn player on random after... although not fair... will have to change the i>0 if statement bc you will need platform[0] and platform[1] to be constant
	//...

	
	
	
	
	
	
	
	
	
	
	
}



